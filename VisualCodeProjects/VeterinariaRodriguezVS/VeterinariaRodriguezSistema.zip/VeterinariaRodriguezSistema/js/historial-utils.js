function renderHistorialClinico(historial, contenedor, onVerArchivos) {
  contenedor.innerHTML = '';

  if (!historial || !Array.isArray(historial) || historial.length === 0) {
    contenedor.innerHTML = '<p>No hay historial clínico registrado para esta mascota.</p>';
    return;
  }

  // Ordenar por fecha descendente
  historial.sort((a, b) => convertirFechaISO(b.fecha) - convertirFechaISO(a.fecha));

  const tabla = document.createElement('table');
  tabla.className = 'table table-bordered table-sm';

  const thead = document.createElement('thead');
  thead.innerHTML = `
    <tr>
      <th>Fecha</th>
      <th>Tipo</th>
      <th>Detalle</th>
      <th>Tratamiento / Costo</th>
      <th>Archivos</th>
      <th>Recordatorios</th>
    </tr>
  `;
  tabla.appendChild(thead);

  const tbody = document.createElement('tbody');

  historial.forEach((h, i) => {
    const tr = document.createElement('tr');

    const fecha = h.fecha || '—';
    const tipo = h.tipo || '—';
    const detalle = h.detalle || '—';
    const tratamiento = h.tratamiento || '—';

    // Archivos
    const tdArchivos = document.createElement('td');
    if (Array.isArray(h.archivos) && h.archivos.length > 0) {
      tdArchivos.innerHTML = h.archivos.map((archivo, idx) => {
        return `<a href="${archivo}" target="_blank">Archivo ${idx + 1}</a>`;
      }).join("<br>");
    } else {
      tdArchivos.textContent = '—';
    }

    // Recordatorios
    let recordatoriosHTML = '—';
    if (Array.isArray(h.recordatorios) && h.recordatorios.length > 0) {
      recordatoriosHTML = h.recordatorios.map(r => {
        const texto = r.texto || '';
        const inicio = r.fechaInicio || '—';
        const proxima = r.fechaProxima || '—';
        return `<div><strong>${texto}</strong><br>Aplicado: ${inicio} | Próxima: ${proxima}</div>`;
      }).join('<hr style="margin:5px 0;">');
    }

    tr.innerHTML = `
      <td>${fecha}</td>
      <td>${tipo}</td>
      <td>${detalle}</td>
      <td>${tratamiento}</td>
    `;
    tr.appendChild(tdArchivos);

    const tdRecordatorios = document.createElement('td');
    tdRecordatorios.innerHTML = recordatoriosHTML;
    tr.appendChild(tdRecordatorios);

    tbody.appendChild(tr);
  });

  tabla.appendChild(tbody);
  contenedor.appendChild(tabla);
}






function convertirFechaISO(fecha) {
  if (!fecha) return new Date('1970-01-01');
  if (/\d{4}-\d{2}-\d{2}T\d{2}:\d{2}/.test(fecha)) return new Date(fecha);

  const parts = fecha.split(", ");
  if (parts.length < 2) return new Date('1970-01-01');
  const [day, month, year] = parts[0].split("/").map(x => parseInt(x));
  let [time, meridian] = parts[1].split(" ");
  if (!time || !meridian) return new Date('1970-01-01');
  if (time.split(":").length === 2) time += ":00";
  let [hour, minute, second] = time.split(":").map(num => parseInt(num));
  if (meridian === 'p.m.' && hour < 12) hour += 12;
  else if (meridian === 'a.m.' && hour === 12) hour = 0;
  return new Date(year, month - 1, day, hour, minute, second);
}





function calcularFechaProxima(fechaBase, texto) {
  let dias = 0;
  const matchValue = typeof texto === 'string' && texto.match(/_(\d+)$/);
  if (matchValue) dias = parseInt(matchValue[1], 10);
  if (!dias && typeof texto === 'string') {
    const matchText = texto.match(/(\d+)\s*d[ií]as?/i);
    if (matchText) dias = parseInt(matchText[1], 10);
  }
  if (!dias) return "—";
  let fecha = new Date();
  if (typeof fechaBase === 'string') {
    const partes = fechaBase.match(/(\d{1,2})\/(\d{1,2})\/(\d{4})/);
    if (partes) {
      const [_, d, m, y] = partes;
      fecha = new Date(`${y}-${m}-${d}`);
    } else {
      const matchISO = fechaBase.match(/(\d{4})-(\d{2})-(\d{2})/);
      if (matchISO) {
        fecha = new Date(fechaBase);
      }
    }
  }
  fecha.setDate(fecha.getDate() + dias);
  return fecha.toISOString().slice(0, 10);
}






